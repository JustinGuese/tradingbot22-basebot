# tradingbot22-basebot
python package

pip install git+https://github.com/JustinGuese/tradingbot22-basebot/

from basebot22.basebot import BaseBot